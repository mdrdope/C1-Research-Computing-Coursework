from .dual import Dual
